# Meu Apê Organizado 🏠💗

Aplicativo nativo para Android, de uso individual e totalmente offline, inspirado no cronograma de organização do apartamento. Sem hospedagem, assinatura ou conta.

## Funcionalidades

- Cronograma completo de segunda a domingo, com tarefas diárias e foco de cada dia.
- Marcar ou desmarcar tarefas, salvo localmente por data.
- Percentual de conclusão e sequência de dias (basta realizar pelo menos uma tarefa naquele dia).
- Notificação padrão às 20h40, configurável.
- Até dois lembretes extras, 20 e 40 minutos depois, se ainda houver tarefas pendentes.
- Reprogramação dos alarmes ao reiniciar o aparelho e após alteração do horário.
- Funciona sem internet depois de instalado.

## Como gerar o APK de graça

**Opção A — com Android Studio no computador:**

1. Instale o Android Studio pelo site oficial developer.android.com/studio (gratuito).
2. Abra a pasta `MeuApeOrganizado` como projeto Android e permita instalar SDK 35 e Gradle 8.9 caso solicitado.
3. Se o Android Studio pedir qual Gradle usar, selecione uma instalação Gradle 8.9 ou configure a distribuição Gradle 8.9.
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK assinado para teste será criado em `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira o APK para o Samsung e abra o arquivo para instalar.

**Opção B — GitHub Actions (sem computador Android Studio, mas requer uma conta no GitHub):**

1. Crie um repositório do GitHub (de preferência público, para usar o Actions de repositórios públicos sem cobrança de minutos).
2. Faça upload dos arquivos *dentro* de `MeuApeOrganizado`, preservando os diretórios — inclusive `.github/workflows/gerar-apk.yml`. Não envie somente o `.zip` fechado, pois o GitHub não o descompacta.
3. Na aba **Actions**, abra o fluxo **Gerar APK gratuito** e execute-o (ou aguarde a execução automática ao enviar os arquivos na branch `main`/`master`).
4. Abra a execução concluída e baixe o artefato **Meu-Ape-Organizado-APK**.
5. Extraia o arquivo e instale `app-debug.apk` no Android.

**Atenção:** este projeto contém o código necessário, mas o APK **não foi compilado nem testado em um dispositivo nesta sessão**, pois o ambiente de geração não tinha o SDK/build tools Android. A primeira compilação pode revelar ajustes ainda não identificados.

## Permissões no Android

- Autorize **Notificações** ao abrir o aplicativo.
- Se quiser tentar lembretes mais pontuais, vá a **Ajustes** e toque em **Permitir alarmes no horário exato** (se o Android oferecer essa permissão).
- A economia de bateria do Android pode atrasar alarmes; não há garantia de exatidão, mesmo com permissão.
- O aplicativo emite sons/vibração conforme o canal de notificações configurado no Android. Não dispara som contínuo de sirene.

## Privacidade e limites

Tudo é salvo no armazenamento privado do aplicativo por data, sem uso da internet. Reinstalar o app pode apagar os registros. Esta versão não sincroniza com iPhone e não usa contas. Não contém compras, anúncios nem rastreadores.
