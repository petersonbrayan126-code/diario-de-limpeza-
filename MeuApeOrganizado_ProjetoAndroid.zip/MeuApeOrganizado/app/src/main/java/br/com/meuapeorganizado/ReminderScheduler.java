package br.com.meuapeorganizado;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.time.LocalDateTime;
import java.time.ZoneId;

public final class ReminderScheduler {
    private ReminderScheduler() {}
    static final int[] OFFSETS = {0, 20, 40};
    static boolean enabled(Context c) { return TaskData.prefs(c).getBoolean("alerts_enabled",true); }
    static int hour(Context c) { return TaskData.prefs(c).getInt("alert_hour",20); }
    static int minute(Context c) { return TaskData.prefs(c).getInt("alert_minute",40); }

    private static PendingIntent intent(Context c, int index) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction("br.com.meuapeorganizado.LEMBRETE_" + index);
        i.putExtra("index",index);
        return PendingIntent.getBroadcast(c, 4200 + index, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static void reschedule(Context c) {
        for(int i=0;i<OFFSETS.length;i++) schedule(c,i);
    }
    static void schedule(Context c, int index) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am == null) return;
        PendingIntent pending = intent(c,index);
        am.cancel(pending);
        if(!enabled(c)) return;
        LocalDateTime next = LocalDateTime.now().withHour(hour(c)).withMinute(minute(c)).withSecond(0).withNano(0)
                .plusMinutes(OFFSETS[index]);
        if(!next.isAfter(LocalDateTime.now())) next = next.plusDays(1);
        long millis = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        try {
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms())
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pending);
            else
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pending);
        } catch(SecurityException err) {
            // Android 12+ may deny exact alarms. Inexact alarms keep reminders working.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pending);
        }
    }
}
