package br.com.meuapeorganizado;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.app.Activity;
import java.time.LocalDate;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CREAM = 0xFFFFFAF6;
    private static final int INK = 0xFF4F3C3D;
    private static final int MUTE = 0xFF8D7776;
    private static final int ROSE = 0xFFE47891;
    private static final int PALE = 0xFFFFEAEB;
    private int selectedDay;
    private boolean created = false;
    private ScrollView page;
    private LinearLayout main;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFFFFE5E9);
        getWindow().setNavigationBarColor(CREAM);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        selectedDay = TaskData.dayIndex(LocalDate.now());
        createChannel();
        ReminderScheduler.reschedule(this);
        render();
        created = true;
    }

    @Override public void onResume() {
        super.onResume();
        if(created) { ReminderScheduler.reschedule(this); render(); }
    }

    private void createChannel() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(nm != null) {
            NotificationChannel c = new NotificationChannel(ReminderReceiver.CHANNEL,
                    "Lembretes da limpeza",NotificationManager.IMPORTANCE_HIGH);
            c.enableVibration(true);
            c.setDescription("Avisos diários para manter o apê organizado");
            nm.createNotificationChannel(c);
        }
    }

    private int dp(float f) { return Math.round(getResources().getDisplayMetrics().density*f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    private GradientDrawable bordered(int color,int strokeColor,int radius) {
        GradientDrawable g = bg(color,radius); g.setStroke(dp(1),strokeColor); return g;
    }
    private TextView text(String str, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(str); t.setTextSize(size); t.setTextColor(color);
        t.setFontFeatureSettings("kern");
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setLineSpacing(dp(2),1.05f);
        return t;
    }
    private LinearLayout column() {
        LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;
    }
    private LinearLayout row() {
        LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;
    }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private void gap(LinearLayout parent,int height){
        View v=new View(this);parent.addView(v,lp(1,dp(height)));
    }
    private void marginCard(LinearLayout parent,View v,int bottom) {
        LinearLayout.LayoutParams l=lp(-1,-2);l.bottomMargin=dp(bottom);parent.addView(v,l);
    }
    private void pad(View v,int horizontal,int vertical){v.setPadding(dp(horizontal),dp(vertical),dp(horizontal),dp(vertical));}
    private TextView pill(String str,int color,int textColor){
        TextView t=text(str,12,textColor,true);pad(t,12,8);t.setGravity(Gravity.CENTER);t.setBackground(bg(color,20));return t;
    }

    private void render() {
        int previousY=page == null ? 0 : page.getScrollY();
        page=new ScrollView(this);
        page.setBackgroundColor(CREAM);
        page.setFillViewport(true);
        main=column();
        pad(main,16,18);
        page.addView(main,new ScrollView.LayoutParams(-1,-2));
        setContentView(page);
        addHeader();
        addPermissionNotice();
        addProgress();
        addDays();
        LocalDate d=TaskData.weekDate(selectedDay);
        addTasksCard("☀️  ROTINA DIÁRIA", "Todos os dias, um pouquinho", TaskData.DAILY, "d",d,0xFFE47891);
        addTasksCard(TaskData.ICONS[selectedDay] + "  FOCO: " + TaskData.TITLES[selectedDay].toUpperCase(new Locale("pt","BR")),
                "Tempo estimado: " + TaskData.TIMES[selectedDay],TaskData.WEEK[selectedDay],"w",d,TaskData.COLORS[selectedDay]);
        addFooter();
        page.post(() -> page.scrollTo(0,previousY));
    }

    private void addHeader() {
        LinearLayout h=column();
        h.setBackground(bordered(0xFFFFF0ED,0xFFF4D2D7,24));
        pad(h,20,22);
        LinearLayout top=row();
        TextView mini=text("🏢  MEU APÊ",13,ROSE,true);
        top.addView(mini,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=pill("⚙  Ajustes",0xFFFFFFFF,INK);
        settings.setOnClickListener(v->openSettings());
        top.addView(settings);
        h.addView(top);
        gap(h,16);
        TextView head=text("CRONOGRAMA DE",22,INK,true);head.setGravity(Gravity.CENTER);
        head.setTypeface(Typeface.SERIF,Typeface.BOLD);h.addView(head);
        TextView script=text("Organização do Apartamento",27,ROSE,true);
        script.setTypeface(Typeface.create("cursive",Typeface.BOLD));
        script.setGravity(Gravity.CENTER);h.addView(script);
        gap(h,6);
        TextView sub=text("Apê organizado, mente leve e coração tranquilo  💗",13,INK,false);
        sub.setGravity(Gravity.CENTER);h.addView(sub);
        marginCard(main,h,12);
    }

    private void addPermissionNotice() {
        boolean needsPermission=Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED;
        if(!needsPermission) return;
        LinearLayout n=row();n.setBackground(bg(0xFFFFE7CF,15));pad(n,12,12);
        TextView t=text("🔔  Toque aqui para permitir os lembretes",14,INK,true);
        n.addView(t);n.setOnClickListener(v->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101));
        marginCard(main,n,12);
    }

    private void addProgress() {
        LocalDate today=LocalDate.now();
        LocalDate d=TaskData.weekDate(selectedDay);
        int completed=TaskData.completed(this,d), total=TaskData.total(d);
        LinearLayout card=column();card.setBackground(bordered(Color.WHITE,0xFFF1E4E0,21));pad(card,17,15);
        LinearLayout first=row();
        LinearLayout labels=column();
        TextView current=text(d.equals(today) ? "✨  Suas tarefas de hoje" : "🗓  Plano de " + TaskData.friendlyDate(d),16,INK,true);
        labels.addView(current);
        gap(labels,2);
        labels.addView(text(completed == total ? "Tudo concluído! Parabéns! 🎉" :
                (total-completed)+" tarefa(s) esperando por você",13,MUTE,false));
        first.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        first.addView(pill("🔥 " + TaskData.streak(this) + " dia(s)",0xFFFFECDF,0xFFAB6036));
        card.addView(first);
        gap(card,13);
        LinearLayout prog=new LinearLayout(this);
        prog.setOrientation(LinearLayout.HORIZONTAL);
        prog.setBackground(bg(0xFFF7E6E6,50));
        int percent=(int)(completed*100.0f/total);
        View fill=new View(this);fill.setBackground(bg(ROSE,50));
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,dp(12),completed);
        if(completed>0) prog.addView(fill,fp);
        if(total-completed>0) {
            View remain=new View(this);
            prog.addView(remain,new LinearLayout.LayoutParams(0,dp(12),total-completed));
        }
        card.addView(prog,new LinearLayout.LayoutParams(-1,dp(12)));
        gap(card,7);
        TextView counter=text(completed+" de "+total+" concluídas · "+percent+"%",12,MUTE,false);
        counter.setGravity(Gravity.RIGHT);card.addView(counter);
        marginCard(main,card,15);
    }

    private void addDays() {
        TextView label=text("ESCOLHA O DIA",12,MUTE,true);
        main.addView(label);gap(main,8);
        HorizontalScrollView horizontal=new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(false);
        LinearLayout buttons=row();
        String[] shortDay={"SEG","TER","QUA","QUI","SEX","SÁB","DOM"};
        for(int i=0;i<7;i++) {
            final int index=i;
            LinearLayout day=column();
            day.setGravity(Gravity.CENTER);
            day.setBackground(i==selectedDay?bg(TaskData.COLORS[i],16):bordered(Color.WHITE,0xFFEEDFE0,16));
            pad(day,14,11);
            TextView text1=text(shortDay[i],12,i==selectedDay?Color.WHITE:INK,true);
            text1.setGravity(Gravity.CENTER);day.addView(text1);
            gap(day,3);
            TextView text2=text(TaskData.friendlyDate(TaskData.weekDate(i)),11,i==selectedDay?Color.WHITE:MUTE,false);
            text2.setGravity(Gravity.CENTER);day.addView(text2);
            LinearLayout.LayoutParams bp=lp(dp(68),-2);bp.rightMargin=dp(6);
            buttons.addView(day,bp);
            day.setOnClickListener(v->{selectedDay=index;render();page.post(()->page.smoothScrollTo(0,0));});
        }
        horizontal.addView(buttons);
        marginCard(main,horizontal,16);
    }

    private void addTasksCard(String title,String subtitle,String[] tasks,String kind,LocalDate date,int accent) {
        LinearLayout card=column();
        card.setBackground(bordered(Color.WHITE,0xFFF0E1DD,22));
        LinearLayout banner=column();banner.setBackground(bg(accent,19));pad(banner,16,12);
        TextView heading=text(title,17,Color.WHITE,true);banner.addView(heading);
        gap(banner,3);
        banner.addView(text(subtitle,12,Color.WHITE,false));
        card.addView(banner);
        gap(card,8);
        for(int i=0;i<tasks.length;i++) {
            boolean done=TaskData.isDone(this,date,kind,i);
            final int idx=i;
            LinearLayout task=row();
            pad(task,14,12);
            TextView heart=text(done?"💗":"♡",26,done?accent:0xFFCDB8B5,true);
            heart.setGravity(Gravity.CENTER);task.addView(heart,lp(dp(37),-2));
            TextView words=text(tasks[i],14,done?0xFF9C9893:INK,false);
            if(done) words.setPaintFlags(words.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            LinearLayout.LayoutParams wl=new LinearLayout.LayoutParams(0,-2,1);
            wl.leftMargin=dp(3);task.addView(words,wl);
            TextView check=text(done?"✓":"○",22,done?accent:0xFFCDB8B5,true);
            task.addView(check);
            task.setContentDescription((done?"Concluída: ":"Pendente: ")+tasks[i]+". Toque para alternar.");
            task.setOnClickListener(v->{
                TaskData.setDone(this,date,kind,idx,!TaskData.isDone(this,date,kind,idx));
                render();
            });
            card.addView(task);
            if(i<tasks.length-1){View div=new View(this);div.setBackgroundColor(0xFFF4E9E6);
                LinearLayout.LayoutParams dl=lp(-1,dp(1));dl.leftMargin=dp(16);dl.rightMargin=dp(16);card.addView(div,dl);}
        }
        gap(card,8);
        marginCard(main,card,15);
    }

    private void addFooter() {
        LinearLayout card=column();pad(card,18,18);card.setBackground(bg(0xFFFFEBED,20));
        TextView message=text("💗  Um passo por dia já transforma tudo!",18,ROSE,true);
        message.setTypeface(Typeface.create("cursive",Typeface.BOLD));
        message.setGravity(Gravity.CENTER);card.addView(message);
        gap(card,8);
        TextView quote=text("Organização não é sobre perfeição. É sobre criar uma rotina que funcione para você!",13,INK,false);
        quote.setGravity(Gravity.CENTER);card.addView(quote);
        gap(card,11);
        card.addView(text("🔔  Alarmes às " + String.format(Locale.getDefault(),"%02d:%02d",ReminderScheduler.hour(this),ReminderScheduler.minute(this))
                + ", com até 2 lembretes extras a cada 20 min, se houver tarefas pendentes.",12,MUTE,false));
        gap(card,8);
        card.addView(text("🔒  Funciona offline. Seus registros ficam só neste celular. Uma tarefa marcada por dia mantém sua sequência 🔥.",12,MUTE,false));
        marginCard(main,card,12);
    }

    private void openSettings() {
        LinearLayout body=column();pad(body,20,12);
        TextView explain=text("Personalize seus avisos. O cronograma fica salvo apenas no seu aparelho.",14,INK,false);
        body.addView(explain);gap(body,16);
        Switch enabled=new Switch(this);
        enabled.setText("Ativar lembretes diários");enabled.setTextColor(INK);
        enabled.setChecked(ReminderScheduler.enabled(this));
        enabled.setOnCheckedChangeListener((b,checked)->{
            TaskData.prefs(this).edit().putBoolean("alerts_enabled",checked).apply();
            ReminderScheduler.reschedule(this);
            if(checked && Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101);
        });
        body.addView(enabled);gap(body,12);
        TextView time=pill("⏰  Horário: " + String.format(Locale.getDefault(),"%02d:%02d",ReminderScheduler.hour(this),ReminderScheduler.minute(this)),0xFFFFE4E9,INK);
        time.setOnClickListener(v->{
            TimePickerDialog picker=new TimePickerDialog(this,(view,h,m)->{
                TaskData.prefs(this).edit().putInt("alert_hour",h).putInt("alert_minute",m).apply();
                ReminderScheduler.reschedule(this);
                time.setText(String.format(Locale.getDefault(),"⏰  Horário: %02d:%02d",h,m));
                render();
            },ReminderScheduler.hour(this),ReminderScheduler.minute(this),true);
            picker.show();
        });
        body.addView(time);gap(body,13);
        TextView msg=text("O aplicativo envia um primeiro lembrete e até mais dois, após 20 e 40 minutos, somente se faltarem tarefas. O Android pode atrasar alertas para economizar bateria.",12,MUTE,false);
        body.addView(msg);gap(body,16);
        if(Build.VERSION.SDK_INT>=31) {
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(am!=null && !am.canScheduleExactAlarms()) {
                TextView exact=pill("🔔  Permitir alarmes no horário exato",0xFFEAE4FB,INK);
                exact.setOnClickListener(v->{
                    try {
                        Intent intent=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        intent.setData(Uri.parse("package:"+getPackageName()));
                        startActivity(intent);
                    } catch(Exception err) {
                        new AlertDialog.Builder(this).setMessage("Abra Configurações > Aplicativos > Meu Apê Organizado > Alarmes e lembretes e autorize o acesso, se disponível.").setPositiveButton("Entendi",null).show();
                    }
                });
                body.addView(exact);gap(body,10);
            }
        }
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            TextView notice=pill("📣  Permitir notificações",0xFFFFF0D8,INK);
            notice.setOnClickListener(v->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101));
            body.addView(notice);
        }
        new AlertDialog.Builder(this).setTitle("⚙  Ajustes do meu apê")
                .setView(body).setPositiveButton("Fechar",(dialog,which)->render()).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==101) { ReminderScheduler.reschedule(this); render(); }
    }
}
