package br.com.meuapeorganizado;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Build;
import java.time.LocalDate;

public class ReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL = "rotina_apartamento_v1";
    @Override public void onReceive(Context context, Intent intent) {
        int index = intent.getIntExtra("index",0);
        if(index < 0 || index >= ReminderScheduler.OFFSETS.length) return;
        ReminderScheduler.schedule(context,index);
        if(!ReminderScheduler.enabled(context)) return;
        LocalDate today = LocalDate.now();
        if(TaskData.allDone(context,today)) return;
        if(Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager manager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL,"Lembretes da limpeza",NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Lembretes do cronograma diário do apartamento");
        channel.enableVibration(true);
        manager.createNotificationChannel(channel);
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent action = PendingIntent.getActivity(context, 200,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        int left = TaskData.total(today) - TaskData.completed(context,today);
        String title = index == 0 ? "🏠 Hora de cuidar do seu apê!" : "💗 Seu apê ainda espera por você!";
        String msg = "Faltam " + left + " tarefas hoje. 20 minutinhos e pronto!";
        Notification n = new Notification.Builder(context,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(msg)
                .setStyle(new Notification.BigTextStyle().bigText(msg + " Toque para marcar as tarefas concluídas."))
                .setContentIntent(action)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setShowWhen(true)
                .build();
        manager.notify(808+index,n);
    }
}
