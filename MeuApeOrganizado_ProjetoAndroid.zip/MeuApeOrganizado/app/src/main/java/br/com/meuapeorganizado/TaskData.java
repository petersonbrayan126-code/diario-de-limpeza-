package br.com.meuapeorganizado;

import android.content.Context;
import android.content.SharedPreferences;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Locale;

public final class TaskData {
    private TaskData() {}
    static final String PREF = "ape_preferencias";
    static final String[] DAYS = {"SEGUNDA-FEIRA", "TERÇA-FEIRA", "QUARTA-FEIRA", "QUINTA-FEIRA", "SEXTA-FEIRA", "SÁBADO", "DOMINGO"};
    static final String[] TITLES = {"Banheiro", "Quartos", "Chão do apê", "Cozinha", "Preparação para o sábado", "Faxina pesada", "Descanso e manutenção"};
    static final String[] ICONS = {"🛁", "🛏️", "🧹", "🍳", "🧺", "🧽", "🌷"};
    static final int[] COLORS = {0xFFE37A90, 0xFF83A984, 0xFFF0B65E, 0xFFA78AC5, 0xFF62A5AF, 0xFFE37A90, 0xFF62A5AF};
    static final String[] TIMES = {"15 a 20 min", "15 a 20 min", "20 a 25 min", "20 a 30 min", "15 a 20 min", "No seu ritmo", "10 a 20 min"};
    static final String[] DAILY = {
        "Fazer a cama ao acordar",
        "Lavar a louça após as refeições",
        "Passar um pano na pia e bancada após o jantar",
        "Colocar roupas sujas no cesto",
        "Guardar objetos fora do lugar (5 min)",
        "Varrer ou passar mop onde mais usa (5 min)"
    };
    static final String[][] WEEK = {
        {"Limpar vaso sanitário", "Passar pano na pia", "Limpar espelho", "Trocar toalhas, se necessário", "Repor papel higiênico e itens de higiene"},
        {"Organizar criado-mudo e cômoda", "Guardar roupas e objetos fora do lugar", "Trocar roupa de cama, se necessário", "Deixar os quartos leves e organizados"},
        {"Varrer todos os cômodos", "Passar pano ou mop em todo o apartamento", "Caprichar na sala, corredor e cozinha", "Deixar tudo cheiroso e leve"},
        {"Limpar micro-ondas", "Limpar fogão ou cooktop", "Limpar bancada e pia", "Conferir geladeira e descartar vencidos", "Organizar armários, se necessário"},
        {"Tirar bagunças dos ambientes", "Esvaziar lixeiras", "Organizar a cozinha", "Separar baldes, rodos e produtos", "Deixar tudo pronto para a faxina"},
        {"Limpar os quartos", "Lavar o banheiro", "Limpar a sala", "Limpar a cozinha", "Lavar varanda/área de serviço, se houver", "Lavar roupas", "Aspirar o sofá, se necessário", "Organizar armários ou despensa"},
        {"Fazer a cama", "Lavar louça", "Dobrar e guardar roupas pendentes", "Organizar os ambientes (10 a 15 min)", "Deixar apenas o essencial em ordem", "Aproveitar seu dia!"}
    };
    static final String[] TIPS = {
        "Pequenas ações diárias evitam acúmulo e sobrecarga.",
        "Disciplina durante a semana deixa o sábado mais leve.",
        "Apê organizado, mente leve e coração tranquilo!",
        "Um passo por dia já transforma tudo!"
    };

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    static int dayIndex(LocalDate date) { return date.getDayOfWeek().getValue() - 1; }
    static String key(LocalDate d, String type, int i) { return "t_" + d + "_" + type + "_" + i; }
    static boolean isDone(Context c, LocalDate d, String type, int i) { return prefs(c).getBoolean(key(d,type,i), false); }
    static void setDone(Context c, LocalDate d, String type, int i, boolean done) { prefs(c).edit().putBoolean(key(d,type,i), done).apply(); }
    static int completed(Context c, LocalDate d) {
        int count = 0;
        for(int i = 0; i < DAILY.length; i++) if(isDone(c,d,"d",i)) count++;
        String[] weekly = WEEK[dayIndex(d)];
        for(int i = 0; i < weekly.length; i++) if(isDone(c,d,"w",i)) count++;
        return count;
    }
    static int total(LocalDate d) { return DAILY.length + WEEK[dayIndex(d)].length; }
    static boolean allDone(Context c, LocalDate d) { return completed(c,d) == total(d); }
    static int streak(Context c) {
        LocalDate date = LocalDate.now();
        if(completed(c, date) == 0) date = date.minusDays(1);
        int days = 0;
        while(days < 366 && completed(c,date) > 0) { days++; date = date.minusDays(1); }
        return days;
    }
    static LocalDate weekDate(int index) {
        LocalDate today = LocalDate.now();
        return today.minusDays(dayIndex(today)).plusDays(index);
    }
    static String friendlyDate(LocalDate d) {
        return String.format(new Locale("pt","BR"), "%02d/%02d",d.getDayOfMonth(),d.getMonthValue());
    }
}
